public class ImplExample implements Hello
{
	//Implementing the interface method
	public void printmsg()
	{
		System.out.println("This is an example of RMI program");	
	}
}